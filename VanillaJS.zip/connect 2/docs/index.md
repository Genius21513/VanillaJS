---
home: true
heroImage: /logo.svg
tagline: Connect your site to Adobe Analytics
actionText: Check the docs →
actionLink: /getting-started/
features:
    - title: Getting Started
      details: All what you need to implement Adobe Analytics
    - title: Options
      details: Check all available options
    - title: What we track?
      details: See how and what is tracked by our script
---

---
