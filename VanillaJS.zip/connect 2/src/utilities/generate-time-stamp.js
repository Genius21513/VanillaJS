const generateTimestamp = () => {
    return Date.now()
}

export default generateTimestamp
