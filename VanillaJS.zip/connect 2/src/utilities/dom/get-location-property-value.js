const getLocationPropertyValue = (propName) => {
    return location[propName]
}

export default getLocationPropertyValue
