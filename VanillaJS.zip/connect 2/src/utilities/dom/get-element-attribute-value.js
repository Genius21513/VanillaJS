const getElementAttributeValue = (element, attributeName) => {
    return element.getAttribute(attributeName)
}

export default getElementAttributeValue
