const getNavigatorPropertyValue = (propertyName) => {
    return navigator[propertyName]
}

export default getNavigatorPropertyValue
